# rsupraya
data wherehouse rsu praya
